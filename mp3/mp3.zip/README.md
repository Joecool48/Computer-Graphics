To start the server run the command:
$ node nodeServer.js
